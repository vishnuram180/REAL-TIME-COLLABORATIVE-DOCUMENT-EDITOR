export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  color: string;
  cursor?: {
    x: number;
    y: number;
    selection?: {
      start: number;
      end: number;
    };
  };
  lastActivity: Date;
}

export interface Document {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  owner: User;
  collaborators: User[];
  isPublic: boolean;
  version: number;
}

export interface Comment {
  id: string;
  content: string;
  author: User;
  position: {
    start: number;
    end: number;
  };
  createdAt: Date;
  replies: Comment[];
  resolved: boolean;
}

export interface DocumentOperation {
  type: 'insert' | 'delete' | 'format';
  position: number;
  content?: string;
  length?: number;
  format?: string;
  author: User;
  timestamp: Date;
}