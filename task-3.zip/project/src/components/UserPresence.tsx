import React from 'react';
import { User } from '../types';

interface UserPresenceProps {
  users: User[];
}

export const UserPresence: React.FC<UserPresenceProps> = ({ users }) => {
  if (users.length === 0) return null;

  return (
    <div className="absolute top-4 right-6 z-40">
      <div className="flex items-center space-x-2 bg-white rounded-full shadow-md px-3 py-2 border border-gray-200">
        <div className="flex -space-x-2">
          {users.slice(0, 4).map((user) => (
            <div
              key={user.id}
              className="relative"
              title={`${user.name} - Active ${formatLastActivity(user.lastActivity)}`}
            >
              <img
                src={user.avatar}
                alt={user.name}
                className="w-8 h-8 rounded-full border-2 border-white shadow-sm"
              />
              <div
                className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white"
                style={{ backgroundColor: user.color }}
              />
            </div>
          ))}
        </div>
        
        {users.length > 4 && (
          <div className="text-sm text-gray-600 font-medium">
            +{users.length - 4} more
          </div>
        )}
        
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span className="text-sm text-gray-600 font-medium">Live</span>
        </div>
      </div>
    </div>
  );
};

function formatLastActivity(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const seconds = Math.floor(diff / 1000);
  
  if (seconds < 30) return 'now';
  if (seconds < 60) return `${seconds}s ago`;
  
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  
  const hours = Math.floor(minutes / 60);
  return `${hours}h ago`;
}