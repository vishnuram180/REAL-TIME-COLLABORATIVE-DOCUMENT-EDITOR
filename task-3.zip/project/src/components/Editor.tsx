import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Bold, Italic, Underline, List, AlignLeft } from 'lucide-react';
import { Document, User, Comment } from '../types';

interface EditorProps {
  document: Document;
  currentUser: User;
  activeUsers: User[];
  onContentChange: (content: string) => void;
  onAddComment: (content: string, position: { start: number; end: number }) => void;
  comments: Comment[];
}

export const Editor: React.FC<EditorProps> = ({
  document,
  currentUser,
  activeUsers,
  onContentChange,
  onAddComment,
  comments,
}) => {
  const [content, setContent] = useState(document.content);
  const [selectedText, setSelectedText] = useState<string>('');
  const [selectionRange, setSelectionRange] = useState<{ start: number; end: number } | null>(null);
  const [showCommentForm, setShowCommentForm] = useState(false);
  const [commentContent, setCommentContent] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setContent(document.content);
  }, [document.content]);

  const handleContentChange = (newContent: string) => {
    setContent(newContent);
    // Debounced save
    const timeoutId = setTimeout(() => {
      onContentChange(newContent);
    }, 500);
    
    return () => clearTimeout(timeoutId);
  };

  const handleTextSelection = () => {
    if (!textareaRef.current) return;
    
    const start = textareaRef.current.selectionStart;
    const end = textareaRef.current.selectionEnd;
    
    if (start !== end) {
      const selected = content.substring(start, end);
      setSelectedText(selected);
      setSelectionRange({ start, end });
      setShowCommentForm(true);
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentContent.trim() && selectionRange) {
      onAddComment(commentContent.trim(), selectionRange);
      setCommentContent('');
      setShowCommentForm(false);
      setSelectedText('');
      setSelectionRange(null);
    }
  };

  const insertFormatting = (format: string) => {
    if (!textareaRef.current) return;
    
    const start = textareaRef.current.selectionStart;
    const end = textareaRef.current.selectionEnd;
    const selectedText = content.substring(start, end);
    
    let newContent = content;
    let replacement = '';
    
    switch (format) {
      case 'bold':
        replacement = `**${selectedText}**`;
        break;
      case 'italic':
        replacement = `*${selectedText}*`;
        break;
      case 'underline':
        replacement = `<u>${selectedText}</u>`;
        break;
    }
    
    newContent = content.substring(0, start) + replacement + content.substring(end);
    setContent(newContent);
    handleContentChange(newContent);
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Toolbar */}
      <div className="border-b border-gray-200 px-6 py-3 bg-white">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => insertFormatting('bold')}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors"
            title="Bold"
          >
            <Bold className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('italic')}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors"
            title="Italic"
          >
            <Italic className="w-4 h-4" />
          </button>
          <button
            onClick={() => insertFormatting('underline')}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors"
            title="Underline"
          >
            <Underline className="w-4 h-4" />
          </button>
          
          <div className="h-6 w-px bg-gray-300 mx-2" />
          
          <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
            <List className="w-4 h-4" />
          </button>
          <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
            <AlignLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      {/* Editor Content */}
      <div className="flex-1 relative">
        <div className="absolute inset-0 p-6">
          <div className="max-w-4xl mx-auto">
            <textarea
              ref={textareaRef}
              value={content}
              onChange={(e) => handleContentChange(e.target.value)}
              onSelect={handleTextSelection}
              className="w-full h-full resize-none border-none outline-none text-gray-900 leading-relaxed text-base font-normal"
              style={{
                fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                lineHeight: '1.6',
              }}
              placeholder="Start writing your document..."
            />
            
            {/* Live Cursors */}
            {activeUsers.map((user) => (
              user.cursor && (
                <div
                  key={user.id}
                  className="absolute pointer-events-none z-10"
                  style={{
                    left: user.cursor.x,
                    top: user.cursor.y,
                    transform: 'translate(-50%, -100%)',
                  }}
                >
                  <div
                    className="w-0.5 h-5 animate-pulse"
                    style={{ backgroundColor: user.color }}
                  />
                  <div
                    className="absolute -top-6 left-0 px-2 py-1 text-xs text-white rounded shadow-lg whitespace-nowrap"
                    style={{ backgroundColor: user.color }}
                  >
                    {user.name}
                  </div>
                </div>
              )
            ))}
          </div>
        </div>
      </div>
      
      {/* Comment Form Modal */}
      {showCommentForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96 max-w-sm mx-4">
            <h3 className="text-lg font-semibold mb-4">Add Comment</h3>
            <div className="mb-4 p-3 bg-gray-100 rounded-md">
              <p className="text-sm text-gray-600 italic">"{selectedText}"</p>
            </div>
            <form onSubmit={handleAddComment}>
              <textarea
                value={commentContent}
                onChange={(e) => setCommentContent(e.target.value)}
                placeholder="Add your comment..."
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                rows={3}
                autoFocus
              />
              <div className="flex justify-end space-x-2 mt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowCommentForm(false);
                    setCommentContent('');
                    setSelectedText('');
                    setSelectionRange(null);
                  }}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Comment</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};