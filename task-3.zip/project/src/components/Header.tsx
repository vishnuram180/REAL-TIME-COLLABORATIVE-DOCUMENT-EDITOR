import React from 'react';
import { FileText, Save, Users, Clock, MoreHorizontal } from 'lucide-react';
import { User, Document } from '../types';

interface HeaderProps {
  currentUser: User;
  currentDocument: Document;
  onSave: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentUser, currentDocument, onSave }) => {
  return (
    <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <FileText className="w-6 h-6 text-blue-600" />
          <span className="font-semibold text-gray-900">DocCollab</span>
        </div>
        
        <div className="h-6 w-px bg-gray-300" />
        
        <div className="flex flex-col">
          <h1 className="text-lg font-medium text-gray-900 leading-tight">
            {currentDocument.title}
          </h1>
          <div className="flex items-center space-x-4 text-sm text-gray-500">
            <span className="flex items-center space-x-1">
              <Clock className="w-3 h-3" />
              <span>Last edited {formatRelativeTime(currentDocument.updatedAt)}</span>
            </span>
            <span>Version {currentDocument.version}</span>
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        <button 
          onClick={onSave}
          className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <Save className="w-4 h-4" />
          <span>Save</span>
        </button>
        
        <div className="flex items-center space-x-2">
          <Users className="w-4 h-4 text-gray-500" />
          <span className="text-sm text-gray-600">
            {currentDocument.collaborators.length + 1} collaborators
          </span>
        </div>
        
        <div className="flex items-center space-x-2">
          <img 
            src={currentUser.avatar} 
            alt={currentUser.name}
            className="w-8 h-8 rounded-full"
          />
          <span className="text-sm font-medium text-gray-700">{currentUser.name}</span>
        </div>
        
        <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-md transition-colors">
          <MoreHorizontal className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};

function formatRelativeTime(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / (1000 * 60));
  
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}