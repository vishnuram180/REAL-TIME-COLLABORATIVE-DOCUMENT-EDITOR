import React from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Editor } from './components/Editor';
import { CommentsPanel } from './components/CommentsPanel';
import { UserPresence } from './components/UserPresence';
import { useCollaboration } from './hooks/useCollaboration';

function App() {
  const {
    currentUser,
    activeUsers,
    documents,
    currentDocument,
    comments,
    updateDocument,
    createDocument,
    setCurrentDocument,
    addComment,
  } = useCollaboration();

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header 
        currentUser={currentUser}
        currentDocument={currentDocument}
        onSave={() => {}} // Auto-save is handled in the hook
      />
      
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          documents={documents}
          currentDocument={currentDocument}
          onSelectDocument={setCurrentDocument}
          onCreateDocument={createDocument}
        />
        
        <div className="flex-1 flex flex-col bg-white relative">
          <UserPresence users={activeUsers} />
          
          <div className="flex-1 flex">
            <div className="flex-1 relative">
              <Editor
                document={currentDocument}
                currentUser={currentUser}
                activeUsers={activeUsers}
                onContentChange={(content) => updateDocument(currentDocument.id, content)}
                onAddComment={addComment}
                comments={comments}
              />
            </div>
            
            <CommentsPanel
              comments={comments}
              currentUser={currentUser}
              onAddComment={addComment}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;