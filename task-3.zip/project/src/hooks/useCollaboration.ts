import { useState, useEffect, useCallback } from 'react';
import { User, Document, Comment, DocumentOperation } from '../types';

// Mock data for demonstration
const mockUsers: User[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    email: 'sarah@example.com',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    color: '#3B82F6',
    lastActivity: new Date(),
  },
  {
    id: '2',
    name: 'Marcus Rodriguez',
    email: 'marcus@example.com',
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    color: '#10B981',
    lastActivity: new Date(),
  },
  {
    id: '3',
    name: 'Aisha Patel',
    email: 'aisha@example.com',
    avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    color: '#F59E0B',
    lastActivity: new Date(),
  },
];

const mockDocuments: Document[] = [
  {
    id: '1',
    title: 'Project Proposal - Q4 Marketing Strategy',
    content: `# Q4 Marketing Strategy Proposal

## Executive Summary

This document outlines our comprehensive marketing strategy for the fourth quarter, focusing on digital transformation and customer engagement initiatives.

## Key Objectives

1. **Increase Brand Awareness** - Target 25% growth in brand recognition
2. **Drive Customer Acquisition** - Achieve 15% increase in new customers
3. **Enhance Digital Presence** - Expand across social media platforms
4. **Optimize Campaign Performance** - Improve ROI by 20%

## Strategic Initiatives

### Digital Marketing Campaign
Our primary focus will be on creating compelling content that resonates with our target audience. We'll leverage data-driven insights to personalize messaging and improve conversion rates.

### Social Media Expansion
We'll establish a stronger presence on emerging platforms while optimizing our existing channels for maximum engagement.

### Partnership Development
Strategic partnerships with complementary brands will help us reach new audiences and create mutually beneficial relationships.

## Timeline and Milestones

- **Week 1-2**: Campaign planning and content creation
- **Week 3-4**: Platform setup and initial launch
- **Week 5-8**: Execution and optimization
- **Week 9-12**: Analysis and reporting

## Budget Allocation

- Digital Advertising: 40%
- Content Creation: 25%
- Social Media Management: 20%
- Analytics and Tools: 10%
- Contingency: 5%

## Expected Outcomes

We anticipate significant improvements in brand metrics, customer acquisition, and overall market positioning by the end of Q4.`,
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date(),
    owner: mockUsers[0],
    collaborators: mockUsers.slice(1),
    isPublic: false,
    version: 12,
  },
  {
    id: '2',
    title: 'Team Meeting Notes - Product Roadmap',
    content: `# Product Roadmap Discussion - Team Meeting

**Date**: January 20, 2024  
**Attendees**: Sarah Chen, Marcus Rodriguez, Aisha Patel, David Kim

## Agenda Items

### 1. Current Sprint Progress
- All features on track for completion
- Minor issues with user authentication flow
- Need to address performance optimization

### 2. Next Quarter Planning
- Focus on mobile responsiveness
- Integration with third-party APIs
- User experience improvements

### 3. Resource Allocation
- Additional designer needed for Q2
- Backend developer starting next month
- QA testing timeline adjustment

## Action Items

- [ ] Sarah: Research mobile optimization tools
- [ ] Marcus: Finalize API documentation
- [ ] Aisha: Coordinate with design team
- [ ] David: Update project timeline

## Key Decisions

1. **Mobile-first approach** for all new features
2. **Weekly standups** to improve communication
3. **User testing sessions** bi-weekly

## Next Steps

Schedule follow-up meeting for February 1st to review progress on action items and finalize Q2 roadmap.`,
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date(),
    owner: mockUsers[1],
    collaborators: [mockUsers[0], mockUsers[2]],
    isPublic: false,
    version: 8,
  },
];

export const useCollaboration = () => {
  const [currentUser] = useState<User>(mockUsers[0]);
  const [activeUsers, setActiveUsers] = useState<User[]>(mockUsers.slice(0, 2));
  const [documents, setDocuments] = useState<Document[]>(mockDocuments);
  const [currentDocument, setCurrentDocument] = useState<Document>(mockDocuments[0]);
  const [comments, setComments] = useState<Comment[]>([]);

  // Simulate real-time user activity
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveUsers(prev => 
        prev.map(user => ({
          ...user,
          cursor: {
            x: Math.random() * 800 + 100,
            y: Math.random() * 600 + 200,
          },
          lastActivity: new Date(),
        }))
      );
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const updateDocument = useCallback((documentId: string, content: string) => {
    setDocuments(prev =>
      prev.map(doc =>
        doc.id === documentId
          ? { ...doc, content, updatedAt: new Date(), version: doc.version + 1 }
          : doc
      )
    );
    
    if (currentDocument.id === documentId) {
      setCurrentDocument(prev => ({
        ...prev,
        content,
        updatedAt: new Date(),
        version: prev.version + 1,
      }));
    }
  }, [currentDocument.id]);

  const createDocument = useCallback((title: string) => {
    const newDocument: Document = {
      id: Date.now().toString(),
      title,
      content: `# ${title}\n\nStart writing your document here...`,
      createdAt: new Date(),
      updatedAt: new Date(),
      owner: currentUser,
      collaborators: [],
      isPublic: false,
      version: 1,
    };
    
    setDocuments(prev => [newDocument, ...prev]);
    setCurrentDocument(newDocument);
  }, [currentUser]);

  const addComment = useCallback((content: string, position: { start: number; end: number }) => {
    const newComment: Comment = {
      id: Date.now().toString(),
      content,
      author: currentUser,
      position,
      createdAt: new Date(),
      replies: [],
      resolved: false,
    };
    
    setComments(prev => [...prev, newComment]);
  }, [currentUser]);

  return {
    currentUser,
    activeUsers,
    documents,
    currentDocument,
    comments,
    updateDocument,
    createDocument,
    setCurrentDocument,
    addComment,
  };
};